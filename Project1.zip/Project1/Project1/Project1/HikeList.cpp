/*
	Wizards Team

	Lane, Shadow
	Delgado, Steven
	Vu, Nhi
	Lam, Dat

	Spring 2022
	CS A250 - C++ 2
	Project: Hiking in the US
*/

#include "Hikelist.h"

#include <iostream>
#include <iomanip>
#include <algorithm>

using namespace std;

void HikeList::addHike(const Hike& addedHike, double hikePrice)
{
	hikeMultimap.insert(pair<Hike, double>(addedHike, hikePrice));
}

void HikeList::addHike(const string& location, 
	const string& nameOfHike, int duration,
	char difficulty, double price)
{
	Hike newHike(location, nameOfHike, duration, difficulty);
	hikeMultimap.insert(pair<Hike, double>(newHike, price));
}


double HikeList::getPrice(const string& hikeName) const 
{
	auto requestedHike = find_if(hikeMultimap.begin(), hikeMultimap.end(),
		[&hikeName](pair<Hike,double> wantedHike)
		{return (wantedHike.first).getHike() == hikeName; });
	return requestedHike->second;
}

void HikeList::printAllLocations() const
{
	auto iterHike = hikeMultimap.begin();
	
	while (iterHike != hikeMultimap.end())
	{
		if ( hikeMultimap.count(iterHike->first) > 1) {
			cout << "\t" << (iterHike->first).getLocation() << endl;
			iterHike = hikeMultimap.upper_bound(iterHike->first);
		}
		else {
			cout << "\t" << (iterHike->first).getLocation() << endl;
			iterHike++;
		}
	}
}

void HikeList::printByLocation(const string& location) const
{
	auto iterHike = hikeMultimap.begin();
	while (iterHike != hikeMultimap.end())
	{
		auto requestedHike = std::find_if(iterHike, hikeMultimap.end(),
			[&location](pair<Hike, double> wantedHike)
			{return (wantedHike.first).getLocation() == location; });
		iterHike = requestedHike;
		if (requestedHike != hikeMultimap.end()) {
			cout << (requestedHike->first);
			cout << "\t" << "  Price (per Person): $ " << fixed
				<< setprecision(2)
				<< this->getPrice((requestedHike->first).getHike())
				<< "\n" << endl;
			iterHike = ++requestedHike;
		}
	}
}

void HikeList::printByDuration() const
{
	multimap<int, string> tempMap;
	auto iterHike = hikeMultimap.begin();
	while (iterHike != hikeMultimap.end())
	{
		string tempString = iterHike->first.getHike() + ", " +
			iterHike->first.getLocation();
		tempMap.insert(pair<int, string>(iterHike->first.getDuration(),
			tempString));
		iterHike++;
	}
	for_each(tempMap.begin(), tempMap.end(), [](pair<int, string> hike)
		{cout << "\t" << "(" << hike.first << ") " 
			<< hike.second << endl; });
}

void HikeList::printByDuration(int duration) const
{
	multimap<int, Hike> tempMap;
	auto iterHike = hikeMultimap.begin();
	while (iterHike != hikeMultimap.end())
	{
		if (iterHike->first.getDuration() == duration) 
		{
			tempMap.insert(pair<int, Hike>(iterHike->first.getDuration(),
				iterHike->first));
		}
		iterHike++;
	}
	for_each(tempMap.begin(), tempMap.end(), [](pair<int, Hike> hike)
		{cout << hike.second << endl; });
}

void HikeList::printByDifficulty(char difficulty) const 
{
	auto iterHike = hikeMultimap.begin();
	for (int i = 0; i < static_cast<int>(hikeMultimap.size()); ++i) 
	{
		if (iterHike->first.getDifficulty() == difficulty) 
		{
			cout << "\t" << "(" << difficulty << ") " 
				<< iterHike->first.getHike()
				<< ", " << iterHike->first.getLocation() << endl;
		}
		iterHike++;
	}
}

void HikeList::printByPrice() const
{
	multimap<double, pair<string, string>> tempMap;

	auto iterHike = hikeMultimap.begin();
	while (iterHike != hikeMultimap.end()) 
	{
		tempMap.emplace(iterHike->second, 
			pair<string, string>(iterHike->first.getHike(),
			iterHike->first.getLocation()));
		iterHike++;
	}

	auto iterTemp = tempMap.begin();
	for (int i = 0; i < static_cast<int>(tempMap.size()); ++i)
	{
		cout << "\t" << "$ ";
		cout.width(8); cout << fixed << right << setprecision(2) 
			<< iterTemp->first;
		cout << " - " << iterTemp->second.second << " (" 
			<< iterTemp->second.first
			<< ")" << endl;
		iterTemp++;
	}
}

void HikeList::printByHikeName(const string& hikeName) const
{
	auto requestedHike = find_if(hikeMultimap.begin(), hikeMultimap.end(),
		[&hikeName](pair<Hike, double> wantedHike)
		{return (wantedHike.first).getHike() == hikeName; });
	cout << (requestedHike->first);
	cout << "\t" <<  "  $" << fixed << setprecision(2)
		<< this->getPrice((requestedHike->first).getHike()) << endl;
}

void HikeList::clearList()
{
	hikeMultimap.erase(hikeMultimap.begin(), hikeMultimap.end());
}