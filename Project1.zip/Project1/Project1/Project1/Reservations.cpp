/*
	Wizards Team

	Lane, Shadow
	Delgado, Steven
	Vu, Nhi
	Lam, Dat

	Spring 2022
	CS A250 - C++ 2
	Project: Hiking in the US
*/

#include "Reservations.h"

#include <iostream>
#include <iomanip>

using namespace std;

int Reservations::addReservation(int memberId, std::string& hikeName)
{
	int reservationNumber = RESERVATION_NUMBER;
	if (size == 0) 
	{
		first = new Node(reservationNumber++, memberId, hikeName,
			nullptr, last);
		last = first;
		size++;
	}
	else 
	{
		last->setNext(new Node(reservationNumber + size, memberId,
			hikeName, last, nullptr));
		last = last->getNext();
		size++;
	}
	return last->getReservationNumber();
}

void Reservations::cancelReservation(int reservNum)
{
	if (size == 1)
	{
		delete first;
		first = nullptr;
		last = nullptr;
	}
	else
	{
		auto canceledRes = findReservation(reservNum);
		if (canceledRes == first)
		{
			first = first->getNext();
			first->getPrev()->setNext(nullptr);
			delete canceledRes;
			canceledRes = nullptr;
		}	
		else if	(canceledRes != last)
		{
			canceledRes->getPrev()->setNext(canceledRes->getNext());
			canceledRes->getNext()->setPrev(canceledRes->getPrev());
			delete canceledRes;
			canceledRes = nullptr;
		}
		else 
		{
			last = last->getPrev();
			last->setNext(nullptr);
			delete canceledRes;
			canceledRes = nullptr;
		}
	}
}

void Reservations::printReservation(int reservNum, HikeList& listOfHikes,
	MemberList& listOfMembers) const
{
	auto iterRes = findReservation(reservNum);
	if (iterRes == nullptr) 
	{
		cerr << "This reservation does not exist.\n";
	}
	else 
	{
		listOfHikes.printByHikeName(iterRes->getHikeName());
		int membPoints = listOfMembers.getPoints(iterRes->getMemberID());
		double hikePrice = listOfHikes.getPrice(iterRes->getHikeName());
		if (membPoints != 0) {
			cout <<  "\n" << "\t" << "Discounted price using points : " 
				<< fixed << setprecision(2) 
				<< (hikePrice - (membPoints / 100)) << "\n";
		}
	}
}

void Reservations::clearList()
{
	auto iterList = first;
	while (first != nullptr) 
	{
		first = first->getNext();
		delete iterList;
		iterList = first;
	}

	size = 0;
	last = nullptr;
}

Reservations::~Reservations() {
	clearList();
}

Node* Reservations::findReservation(int reservNum) const
{
	auto iter = first;
	while (iter->getReservationNumber() != reservNum)
	{
		iter = iter->getNext();
		if (iter == last->getNext()) 
		{
			return nullptr;
		}
	}
	return iter;
}