/*
	Wizards Team

	Lane, Shadow
	Delgado, Steven
	Vu, Nhi
	Lam, Dat

	Spring 2022
	CS A250 - C++ 2
	Project: Hiking in the US
*/

#include "Interface.h"

#include "iostream"
#include "algorithm"

using namespace std;

MemberList::MemberList()
{
	listOfMember = new set<Member>;
}

//Inserts ID into the set the object of type Member
void MemberList::addMember(const string& firstName, 
	const string& lastName)
{
	Member newMember(firstName, lastName);	
	int memberId = STARTING_ID;
	if (listOfMember->size() == 0)
	{
		newMember.setID(memberId);
	}
	else
	{
		newMember.setID((listOfMember->rbegin())->getID() + 1);
	}
	listOfMember->insert(newMember);	
}

//Inserts ID and points into the set the object of type Member
void MemberList::addMember(const string& firstName, 
	const string& lastName, int points)
{
	Member newMember(firstName, lastName);
	newMember.addPoints(points);
	int memberId = STARTING_ID;
	if (listOfMember->size() == 0)
	{
		newMember.setID(memberId);
	}
	else
	{
		newMember.setID((listOfMember->rbegin())->getID() + 1);
	}
	listOfMember->insert(newMember);
}

// Returns the ID of the last member in the list.
int MemberList::getLastID() const
{
	return ((listOfMember->rbegin())->getID());
}

int MemberList::getPoints(int myID) const
{
	auto seachPoints = find_if(listOfMember->begin(),
		listOfMember->end(), 
		[&myID](const auto& member) 
		{return(member.getID() == myID);});
	return (seachPoints)->getPoints();
}

//Print if ID number is found and the last name matches that ID number.
void MemberList::printMember(int myID, 
	const string& myLastName) const
{
	auto searchID = find_if(listOfMember->begin(), 
		listOfMember->end(), 
		[&myID](const auto& member) 
		{return (member.getID() == myID);});
	if (searchID != listOfMember->end())
	{
		searchID->printMember();
		cout << "\tMembership # " << searchID->getID() << endl;
	}
}

void MemberList::clearList()
{
	listOfMember->clear();
}

MemberList::~MemberList()
{
	delete listOfMember;
	listOfMember = nullptr;
}
